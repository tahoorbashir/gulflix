const Settings = () => {
  return <></>;
};

export default Settings;
