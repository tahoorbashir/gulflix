import CategorywisePage from "@/components/CategorywisePage";

const Tv = () => {
  return <CategorywisePage categoryDiv="tv" />;
};

export default Tv;
